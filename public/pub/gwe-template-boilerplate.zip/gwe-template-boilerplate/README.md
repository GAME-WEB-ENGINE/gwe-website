## Installation (NodeJS)
```
npm install
```

## Lancement
```
npm start
```
