## Installation (NodeJS)
```
npm install
```

## Lancement
```
npm start
```
## Todo
- ajouter 