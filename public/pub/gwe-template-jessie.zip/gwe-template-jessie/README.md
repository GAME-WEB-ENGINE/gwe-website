+ TODO:
-------

Ajouter sprites dans la scène.
Explorer la piste de la composition pour éviter l'héritage vers les classes Gfx car cela oblige à gérer les updates en dehors des classes ciblée.
models folder rename to entities.
