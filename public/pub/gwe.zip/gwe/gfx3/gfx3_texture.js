/**
 * Classe représentant une texture.
 */
class Gfx3Texture {
  constructor() {
    this.glt = null;
    this.width = 1;
    this.height = 1;
  }
}

module.exports.Gfx3Texture = Gfx3Texture;